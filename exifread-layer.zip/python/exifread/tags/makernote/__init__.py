"""
Makernote tag definitions.
"""
